package com.velocity.starter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.velocity.Template;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.context.Context;
import org.apache.velocity.servlet.VelocityServlet;

@SuppressWarnings({ "deprecation" })
public class VelocityTemplate extends VelocityServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected Template handleRequest(HttpServletRequest request, HttpServletResponse response, Context ctx)
			throws Exception {
		Template templ = null;
		
		try{
			ctx.put("name", "Vishal");
			templ = Velocity.getTemplate("/WEB-INF/veltemplates/helloworld.vm");
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return templ;
		
	}

}
