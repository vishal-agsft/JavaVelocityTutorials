package com.velocity.starter;

import java.io.StringWriter;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;

public class HelloVelocity {

	public static void main(String[] args) {
		startVelocityEngine();
	}

	private static void startVelocityEngine() {
		VelocityEngine ve = new VelocityEngine();
		ve.init(); // creates a new instance and then initializes the engine

		// gets the inbuilt helloworld template
		Template velocTemp = ve.getTemplate("helloworld.vm");

		// context creation and adding data in jsp style
		VelocityContext velocityContext = new VelocityContext();
		velocityContext.put("name", "Velocity");

		// rendering the template in a string writer...
		StringWriter writer = new StringWriter();
		velocTemp.merge(velocityContext, writer);
	}

}
